const swal_bootstrap = Swal.mixin({
    customClass: {
        Button: 'btn btn-primary swal-button-fix',
        confirmButton: 'btn btn-primary swal-button-fix',
        cancelButton: 'btn btn-danger swal-button-fix'
    },
    buttonsStyling: false
})