from models import *


def get_prod_range(start, end=None, username=None):
    if not end:
        end = start

    if (not isinstance(start, datetime.datetime)):
        start = datetime.datetime.strptime(start, "%m-%d-%Y").date()

    if (not isinstance(end, datetime.datetime)):
        end = datetime.datetime.strptime(end, "%m-%d-%Y").date()

    if not username:
        return {
            "prod": [prod_data.as_dict() for prod_data in
                     Prod.query.filter(Prod.build_audit_date >= start, Prod.build_audit_date <= end).all()],
            "non_prod": [non_prod_data.as_dict() for non_prod_data in
                         NonProd.query.filter(NonProd.work_date >= start, NonProd.work_date <= end).all()]
        }

    return {
        "prod": [prod_data.as_dict() for prod_data in
                 Prod.query.filter(Prod.build_audit_date >= start, Prod.build_audit_date <= end,
                                   Prod.user_id == username).all()],
        "non_prod": [non_prod_data.as_dict() for non_prod_data in
                     NonProd.query.filter(NonProd.work_date >= start, NonProd.work_date <= end,
                                          NonProd.user_id == username).all()]
    }, (start - end).days


def calc_prod(start, end=None, username=None):
    data, days = get_prod_range(start, end, username)
    if days == 0:
        days = 1
    util_minutes = 0
    prod_minutes = 0
    non_prod_time_taken = 0
    normal_prod_minutes = 0
    for prod_data in data["prod"]:
        prod_minutes = prod_minutes + prod_data["deal_count"] * AHT.query.get(prod_data["deal_id"]).as_dict()[
            prod_data["build_audit"].lower()]
        normal_prod_minutes += prod_data["utilization"]
        util_minutes = util_minutes + prod_data["utilization"]

    for non_prod_data in data["non_prod"]:
        non_prod_time_taken = non_prod_time_taken + non_prod_data["time_taken"]

    minutes = prod_minutes + non_prod_time_taken
    daily_prod = round((minutes / 480 * days) * 100, 2)
    # uti_min = util_minutes + non_prod_time_taken
    uti_min = normal_prod_minutes + non_prod_time_taken
    daily_uti = round((uti_min / 480 * days) * 100, 2)

    # print('User', {username})
    # print('Prod in mins', {normal_prod_minutes})
    # print('Non Prod time taken', {non_prod_time_taken})
    # print('Daily productivity', {daily_prod})
    # print('Daily utilization', {daily_uti})
    results = [{
        "username": username,
        "prod_mins": normal_prod_minutes,
        "non_prod_mins": non_prod_time_taken,
        "util_mins": uti_min,
        "daily_prod": daily_prod,
        "daily_util": daily_uti
    }]
    return results


def get_daily(start, end):
    # calc_prod("05-26-2023", None, 'simmnu')
    prod_usernames = set()
    non_prod_usernames = set()

    # Get unique usernames from Prod data
    prod_data = get_prod_range(start, end)
    for prod_entry in prod_data["prod"]:
        prod_usernames.add(prod_entry["user_id"])

    # Get unique usernames from NonProd data
    non_prod_data = get_prod_range(start, end)
    for non_prod_entry in non_prod_data["non_prod"]:
        non_prod_usernames.add(non_prod_entry["user_id"])

    # Combine the unique usernames from both Prod and NonProd data
    all_usernames = prod_usernames.union(non_prod_usernames)

    results = []
    for username in all_usernames:
        result = calc_prod(start, end, username)
        results.append(result)

    return results


def get_range_prod(start_date, end_date=None, username=None):
    data = get_prod_range(start_date, end_date)
    prod_data = {}
    non_prod_data = {}

    for d in data["prod"]:
        if d["user_id"] not in prod_data.keys():
            prod_data[d["user_id"]] = {}
        dates = []
        if d["build_audit_date"] not in dates:
            dates.append(d["build_audit_date"])

        for date in dates:
            prod_data[d["user_id"]][date.strftime("%Y-%m-%d")] = []

    for d in data["prod"]:
        if d["user_id"] in prod_data.keys():
            if d["build_audit_date"].strftime("%Y-%m-%d") in prod_data[d["user_id"]].keys():
                prod_data[d["user_id"]][d["build_audit_date"].strftime("%Y-%m-%d")].append(d)

    for user in prod_data:
        for worked_date in prod_data[user]:
            worked_prod = {
                "length": len(prod_data[user][worked_date]),
                "prod_mins": 0,
                "util_mins": 0,
                # "normal_prod_mins": 0,
            }
            for worked_data in prod_data[user][worked_date]:
                worked_prod["prod_mins"] += worked_data["deal_count"] * AHT.query.get(worked_data["deal_id"]).as_dict()[
                    worked_data["build_audit"].lower()]
                # worked_prod["normal_prod_mins"] += worked_data["utilization"]
                worked_prod["util_mins"] += worked_data["utilization"]
            work_data = prod_data[user][worked_date]
            prod_data[user][worked_date] = {
                # "data": work_data,
                "calced": worked_prod
            }

    for d in data["non_prod"]:
        if d["user_id"] not in non_prod_data.keys():
            non_prod_data[d["user_id"]] = {}
        dates = []
        if d["work_date"] not in dates:
            dates.append(d["work_date"])

        for date in dates:
            non_prod_data[d["user_id"]][date.strftime("%Y-%m-%d")] = []

    for d in data["non_prod"]:
        if d["user_id"] in non_prod_data.keys():
            if d["work_date"].strftime("%Y-%m-%d") in non_prod_data[d["user_id"]].keys():
                non_prod_data[d["user_id"]][d["work_date"].strftime("%Y-%m-%d")].append(d)

    for user in non_prod_data:
        for worked_date in non_prod_data[user]:
            worked_prod = {
                "length": len(non_prod_data[user][worked_date]),
                "non_prod_mins": 0,
                "time_taken":0
            }
            for worked_data in non_prod_data[user][worked_date]:
                worked_prod["non_prod_mins"] += worked_data["time_taken"]
                worked_prod["time_taken"] += worked_data["time_taken"]
            non_prod_data[user][worked_date] = {
                # "data": work_data,
                "calced": worked_prod
            }
    print(prod_data)
    print(non_prod_data)

    users_to_check = list(prod_data.keys()) + list(non_prod_data.keys())
    print(users_to_check)

    overall_data = {}
    for user in users_to_check:
        if user not in overall_data.keys():
            overall_data[user] = {}

        if user in prod_data.keys():
            for date in prod_data[user]:
                if date not in overall_data[user].keys():
                    overall_data[user][date] = {}
                overall_data[user][date]["prod_data"] = prod_data[user][date]

        if user in non_prod_data.keys():
            for date in non_prod_data[user]:
                if date not in overall_data[user].keys():
                    overall_data[user][date] = {}
                overall_data[user][date]["non_prod_data"] = non_prod_data[user][date]

        for date in overall_data[user]:
            overall_data[user][date]["calced_prod"] = {
                # "nrml_prod_mins": overall_data[user][date]["prod_data"]["calced"]["normal_prod_mins"] if "prod_data" in
                #                                                                                          overall_data[
                #                                                                                              user][
                #                                                                                              date] else 0,
                "prod_mins": overall_data[user][date]["prod_data"]["calced"]["prod_mins"] if "prod_data" in
                                                                                             overall_data[user][
                                                                                                 date] else 0,
                "non_prod_mins": overall_data[user][date]["non_prod_data"]["calced"][
                    "non_prod_mins"] if "non_prod_data" in overall_data[user][date] else 0,
                "Time_Taken": overall_data[user][date]["non_prod_data"]["calced"]["time_taken"] if "non_prod_data" in overall_data[user][date] else 0,
                "util_mins": overall_data[user][date]["prod_data"]["calced"]["util_mins"] if "prod_data" in
                                                                                             overall_data[user][
                                                                                                 date] else 0
            }

            overall_data[user][date]["calced_prod"]["daily_prod"] = round(((overall_data[user][date]["calced_prod"]["prod_mins"] + overall_data[user][date]["calced_prod"]["non_prod_mins"]) / 480 * 1) * 100, 2)

            overall_data[user][date]["calced_prod"]["daily_util"] = round(((overall_data[user][date]["calced_prod"]["util_mins"]) / 480 * 1) * 100, 2)

    print(overall_data)
    total_range_data = {}

    for user in overall_data.keys():
        if user not in total_range_data:
            total_range_data[user] = {
                "worked_dates": [],
                "total_calc": {}
            }

        total = {
            "prod_mins": 0,
            "non_prod_mins": 0,
            "util_mins": 0,
            # "nl_prod_mins": 0
        }
        for date in overall_data[user].keys():

            if date not in total_range_data[user]["worked_dates"]:
                total_range_data[user]["worked_dates"].append(date)
            total["prod_mins"] += overall_data[user][date]["calced_prod"]["prod_mins"]
            # total["nl_prod_mins"] += overall_data[user][date]["calced_prod"]["prod_mins"]
            total["non_prod_mins"] += overall_data[user][date]["calced_prod"]["non_prod_mins"]
            total["util_mins"] += overall_data[user][date]["calced_prod"]["util_mins"] + overall_data[user][date]["calced_prod"]["Time_Taken"]

        total["daily_prod"] = round(((total["prod_mins"] + total["non_prod_mins"]) / 480 / len(total_range_data[user]["worked_dates"])) * 100, 2)
        total["daily_util"] = round((total["util_mins"] / (480 * len(total_range_data[user]["worked_dates"]))) * 100, 2)
        total_range_data[user]["total_calc"] = total
    return total_range_data


# print(get_range_prod("05-20-2023", "06-18-2023"))
# quit()


config = {
    "NA KC Deals": {
        "includes": {"process": ["US_NA Deals", "CA_NA Deals"]},
        "excludes": {"deal": ["Item Safety"]}
    },
    "Deals Pbook": {
        "includes": {"process": ["US_NA_Deals_Pbooks"]}
    },
    "Item Safety-Deals": {
        "includes": {"deal": ["Item Safety"]}
    },
    "NA KC APUB": {
        "includes": {"process": ["US_APUB"]}
    },
    "Apub IS": {
        "includes": {"process": ["Item Safety"]}
    },
    "KDP": {
        "contains": {"process": ["KDP"]}
    },
    "Indie Publishing": {
        "includes": {"process": ["Indie"]}
    },
    "KDP Item Safety": {
        "includes": {"process": ["Item Safety"]}
    },
    "ABR (Includes US and Upcoming MPs)": {
        "includes": {"process": ["ABR"]}
    },
    "Specialty Reading (Includes SR IS and Book Trailers)": {
        "includes": {"process": ["Specialty_Reading"]}
    },
    "BR Customer Life Cycle (CLC)": {
        "includes": {"deal": ["CLC- Reactivation campaign", "CLC-PA campaigns", "Free ebooks campaigns"]}
    },
    "Merch - BR": {
        "includes": {"process": ["BR_Merch"]},
        "excludes": {"deal": ["CLC- Reactivation campaign", "CLC-PA campaigns", "Free ebooks campaigns"]}
    },
    "Kindle Comics - US": {
        "includes": {"process": ["US_Kindlecomics"]}
    },
    "Kindle Comics - UK": {
        "includes": {"process": ["UK_Kindlecomics"]}
    },
    "Paid Marketing": {
        "includes": {"process": ["Paid_Marketing"]}
    },
    "Comixology": {
        "includes": {"process": ["Comixology"]}
    },
    "Merch-SG": {
        "includes": {"process": ["SG"]}
    },
    "ART": {
        "includes": {"process": ["ART"]}
    }
}


def get_range_merch(start_date, end_date=None):
    print(start_date, end_date)
    data = get_prod_range(start_date, end_date)
    calculated_values = {}
    for category in config:
        inclusions = {
            "process": [],
            "deal": []
        }
        exclusions = {
            "process": [],
            "deal": []
        }
        if config[category].get("includes"):
            if config[category]["includes"]:
                if config[category]["includes"].get("process"):
                    inclusions["process"] = [i.as_dict()["id"] for i in Process.query.filter(
                        Process.name.in_(config[category]["includes"].get("process"))).all()]
                if config[category]["includes"].get("deal", None):
                    inclusions["deal"] = [i.as_dict()["id"] for i in Deal.query.filter(
                        Deal.name.in_(config[category]["includes"].get("deal"))).all()]

        if config[category].get("excludes"):
            if config[category]["excludes"]:
                if config[category]["excludes"].get("process"):
                    exclusions["process"] = [i.as_dict()["id"] for i in Process.query.filter(
                        Process.name.in_(config[category]["excludes"].get("process"))).all()]
                if config[category]["excludes"].get("deal"):
                    exclusions["deal"] = [i.as_dict()["id"] for i in Deal.query.filter(
                        Deal.name.in_(config[category]["excludes"].get("deal"))).all()]

        for prod_data in data["prod"]:
            if prod_data["process_id"] in inclusions["process"] or prod_data["deal_id"] in inclusions["deal"]:
                if category not in calculated_values:
                    calculated_values[category] = {
                        "email": 0,
                        "onsite": 0,
                        "push": 0,
                        "vendisto": 0,
                        "validation": 0,
                    }

                calculated_values[category]["email"] += prod_data.get("emails_count", 0)
                calculated_values[category]["onsite"] += prod_data.get("onsite_count", 0)
                calculated_values[category]["push"] += prod_data.get("pns_count", 0)
                calculated_values[category]["vendisto"] += prod_data.get("vendisto_count", 0)
                calculated_values[category]["validation"] += prod_data.get("validation_count", 0)

                if prod_data["process_id"] in exclusions["process"] or prod_data["deal_id"] in exclusions["deal"]:
                    if category not in calculated_values:
                        calculated_values[category] = {
                            "email": 0,
                            "onsite": 0,
                            "push": 0,
                            "vendisto": 0,
                            "validation": 0,
                        }

                    calculated_values[category]["email"] -= prod_data.get("emails_count", 0)
                    calculated_values[category]["onsite"] -= prod_data.get("onsite_count", 0)
                    calculated_values[category]["push"] -= prod_data.get("pns_count", 0)
                    calculated_values[category]["vendisto"] -= prod_data.get("vendisto_count", 0)
                    calculated_values[category]["validation"] -= prod_data.get("validation_count", 0)

    return calculated_values

# print(get_range_merch("08-01-2023", "08-22-2023"))
